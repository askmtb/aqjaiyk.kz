# Интеграция меню в `aqjaiyk.kz`

Этот пакет добавляет страницу меню в существующий проект. Совместим со стеком из `CLAUDE.md`:
Vite + React 19 + TS + Tailwind v4 + shadcn/ui + React Router v7 + TanStack Query + Supabase + PWA.

## Что добавляется

```
src/
├── data/
│   ├── menu.json              ← 114 позиций, 14 категорий
│   └── fines.json             ← порча мебели и бой посуды (для админки)
├── types/
│   └── menu.ts                ← типы Menu / MenuCategory / MenuItem
├── lib/menu/
│   ├── queries.ts             ← useMenu() — React Query хук
│   └── format.ts              ← formatPrice(), расчёт обслуживания
├── components/menu/
│   ├── MenuItem.tsx           ← карточка блюда
│   ├── MenuCategorySection.tsx
│   └── MenuCategoryNav.tsx    ← sticky pills с scroll-spy
└── pages/
    └── MenuPage.tsx           ← главная страница меню

supabase/
├── migrations/
│   ├── 0001_menu.sql          ← схема таблиц + RLS
│   ├── 0002_menu_seed.sql     ← seed на 114 позиций
│   └── 0003_fines_seed.sql    ← seed на 21 штрафную позицию
└── generate_seed.py           ← регенерация seed из JSON
```

## Шаг 1. Скопировать файлы

Положить файлы из этого пакета в корень репозитория, сохраняя структуру путей. Все импорты используют alias `@/` → `src/` (стандарт для shadcn/ui), он у вас уже настроен в `tsconfig.app.json` и `vite.config.ts`.

## Шаг 2. Подключить роут

В файле, где определены роуты (обычно `src/App.tsx` или `src/main.tsx`):

```tsx
import { MenuPage } from "@/pages/MenuPage";

<Route path="/menu" element={<MenuPage />} />
```

Если хотите чтобы меню открывалось с главной — задайте `path="/"`.

## Шаг 3. Убедиться что есть `cn` утилита

Компоненты импортируют `cn` из `@/lib/utils`. У вас в зависимостях уже есть `clsx` и `tailwind-merge` — это shadcn-паттерн. Если файла нет, создайте `src/lib/utils.ts`:

```ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

## Шаг 4. (Опционально) Применить миграции Supabase

Когда Supabase ref будет готов:

```bash
supabase link --project-ref <your-ref>
supabase db push   # применит миграции из supabase/migrations/
```

Или вручную: открыть SQL Editor в дашборде Supabase и выполнить файлы в порядке `0001 → 0002 → 0003`.

## Шаг 5. (После шага 4) Переключить источник данных

В `src/lib/menu/queries.ts` есть закомментированный пример Supabase-fetch. Раскомментировать, удалить чтение из JSON. Компоненты не трогать — типы те же.

```ts
queryFn: async (): Promise<Menu> => {
  const { data, error } = await supabase
    .from("menu_categories")
    .select("id:slug, name, subtitle, items:menu_items(...)")
    .order("sort_order")
    .order("sort_order", { foreignTable: "menu_items" });
  if (error) throw error;
  return { ...meta, categories: data };
};
```

## Что меняется в JSON → пересобрать seed

Если редактируете `src/data/menu.json` (исправили цену, добавили блюдо):

```bash
python3 supabase/generate_seed.py
```

Получите новый `0002_menu_seed.sql`. Прогон идемпотентный (`on conflict do update`), Supabase обновит существующее.

## Дальнейшие шаги (по плану из CLAUDE.md)

### Phase 2 — корзина и Kaspi Pay

`MenuItem` уже принимает `onAdd?: (item) => void`. В `MenuPage`:

```tsx
import { useCart } from "@/lib/cart";

const cart = useCart();

<MenuCategorySection
  category={cat}
  currencySymbol={menu.currencySymbol}
  onAddItem={(item) => cart.add(item)}
/>
```

Kaspi-ссылка по `CLAUDE.md`:
```ts
const url = `https://pay.kaspi.kz/pay/${import.meta.env.VITE_KASPI_SHOP_ID}?amount=${total}`;
```

### Phase 3 — админка

Все таблицы готовы к админ-управлению: RLS даёт `select all / write authenticated`. Можно скопировать паттерн `useMenu` для `useMenuMutation` через `useMutation` + Supabase upsert.

### Phase 4 — PWA

Меню работает офлайн «из коробки», пока источник = локальный JSON: Vite билдит данные в bundle. После переключения на Supabase — добавить runtime caching в `vite-plugin-pwa`:

```ts
runtimeCaching: [{
  urlPattern: /\/rest\/v1\/menu_/,
  handler: "StaleWhileRevalidate",
  options: { cacheName: "menu-cache" },
}]
```

### Phase 5 — брендинг

Сейчас цвета — нейтральный zinc-9. После получения логотипа и палитры — заменить классы `bg-zinc-900` / `text-zinc-900` на CSS-переменные темы (`bg-primary` / `text-primary`) в `MenuItem`, `MenuCategoryNav`. shadcn-токены в `@theme` Tailwind v4.

## Замечания по данным

- Цены — целые числа в тенге, без копеек
- Соусы (майонез/кетчуп/сметана) — `price: 0` (PDF не указывал цену) → отображаются как «—». Поправить в JSON если они платные
- `preorder: true` стоит у 6 позиций: бауырсаки, манты с картофелем, филе судака, баклажановые/кабачковые/спринг роллы, фирменная закуска АҚ ЖАЙЫҚ
- `serviceChargePercent: 10` — выводится в футере страницы и используется в `calculateTotalWithService()` для Phase 2
- Штрафы (`fines.json`, таблицы `fine_*`) — **не для гостевого меню**, RLS закрывает их от анонимов

## Что осталось / следующие шаги

- [ ] Положить файлы в репо и запустить `npm run dev`
- [ ] Подключить роут `/menu` в `App.tsx`
- [ ] Открыть на телефоне (mobile-first проверка)
- [ ] Когда Supabase ref появится — `supabase db push` и переключить `queries.ts`
- [ ] Заменить нейтральные классы на токены темы после получения логотипа
