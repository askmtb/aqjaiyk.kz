import { useMenu } from "@/lib/menu/queries";
import { MenuCategoryNav } from "@/components/menu/MenuCategoryNav";
import { MenuCategorySection } from "@/components/menu/MenuCategorySection";

/**
 * Страница меню Aq Jaiyk.
 *
 * Подключить в роутер (см. MENU_INTEGRATION.md):
 *   <Route path="/menu" element={<MenuPage />} />
 *
 * Для Phase 2 (корзина + Kaspi Pay) — пробросить onAddItem из useCart().
 */
export function MenuPage() {
  const { data: menu, isLoading, error } = useMenu();

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center text-zinc-500">
        Загрузка меню…
      </div>
    );
  }

  if (error || !menu) {
    return (
      <div className="flex min-h-screen items-center justify-center text-red-600">
        Не удалось загрузить меню
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <header className="px-4 pt-6 pb-2">
        <h1 className="text-2xl font-bold tracking-tight text-zinc-900">
          Меню
        </h1>
        <p className="text-sm text-zinc-500">Кафе {menu.restaurant}</p>
      </header>

      <div className="px-4">
        <MenuCategoryNav categories={menu.categories} />
      </div>

      <main className="space-y-10 px-4 py-6 pb-24">
        {menu.categories.map((cat) => (
          <MenuCategorySection
            key={cat.id}
            category={cat}
            currencySymbol={menu.currencySymbol}
            // Phase 2: onAddItem={(item) => addToCart(item)}
          />
        ))}

        <footer className="border-t border-zinc-200 pt-4 text-xs text-zinc-500">
          {menu.note}
        </footer>
      </main>
    </div>
  );
}

export default MenuPage;
